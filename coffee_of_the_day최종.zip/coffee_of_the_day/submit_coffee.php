<?php
$db_host = 'your_database_host';
$db_user = 'your_database_user';
$db_password = 'your_database_password';
$db_name = 'your_database_name';

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $coffee_name = $_POST['name'];
    $calories = $_POST['email'];
    $caffeine = $_POST['subject'];
    $review = $_POST['message'];

    $sql = "INSERT INTO coffee_info (coffee_name, calories, caffeine, review) VALUES ('$coffee_name', $calories, $caffeine, '$review')";
    if ($conn->query($sql) === TRUE) {
        echo '커피 정보가 성공적으로 저장되었습니다.';
    } else {
        echo '오류: ' . $sql . '<br>' . $conn->error;
    }
}

$conn->close();
?>
