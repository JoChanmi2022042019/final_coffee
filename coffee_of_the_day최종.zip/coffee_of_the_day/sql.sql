CREATE TABLE coffee_info (
    id INT AUTO_INCREMENT PRIMARY KEY,
    coffee_name VARCHAR(255) NOT NULL,
    calories INT NOT NULL,
    caffeine INT NOT NULL,
    review TEXT
);